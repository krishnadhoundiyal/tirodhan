# Recorded geographical QA run

Executions: 4; authoritative ACTIVATED cycles: 4.

Actual engine calls: `{'VROOM': 268, 'OR_TOOLS': 268, 'CP_SAT_COORDINATOR': 8, 'CP_SAT_STAGES': 32}`.

Failures are acceptance failures, not successful optimization. See QA_EXECUTIONS.json and QA_INVARIANTS.json. Public OSM synthetic scenario; map edges are schematic only.
